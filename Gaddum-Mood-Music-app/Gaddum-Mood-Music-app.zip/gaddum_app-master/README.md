# gaddum_app
The consumer app for the [gaddum project](https://cmdt.github.io/gaddum/). Play music for your mood.

This repository contains the code for the Ionic + Cordova crossplatform mobile app.

The master branch holds the release code, which builds for mobile. 

The development branches are used for the development of features and contribute to the master branch when the feature is complete.

When releasing a new version, the python script setcordovaversion.py is used to correctly update the version information in the config.xml file.

Please take a look at our project contributors and supporters [here](./attribution/attribution.md).


