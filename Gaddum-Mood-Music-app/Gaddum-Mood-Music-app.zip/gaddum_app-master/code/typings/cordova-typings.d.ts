
/// <reference path="../.vscode/typings/cordova/cordova.d.ts"/>
/// <reference path="../.vscode/typings/ionic/ionic.d.ts"/>
/// <reference path="../.vscode/typings/cordova-ionic/plugins/keyboard.d.ts"/>
/// <reference path="../.vscode/typings/angularjs/angular.d.ts"/>
/// <reference path="../.vscode/typings/jquery/jquery.d.ts"/>
/// <reference path="..\.vscode\typings\cordova\cordova.d.ts"/>
/// <reference path="..\.vscode\typings\cordova-ionic\plugins\keyboard.d.ts"/>
/// <reference path="..\.vscode\typings\ionic\ionic.d.ts"/>
/// <reference path="..\.vscode\typings\angularjs\angular.d.ts"/>
/// <reference path="..\.vscode\typings\jquery\jquery.d.ts"/>