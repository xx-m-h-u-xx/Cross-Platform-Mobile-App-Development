(function(){
  'use strict';

  angular
    .module('gaddum.playlists')
    .controller('playlistsListController', playlistsListController);

  playlistsListController.$inject = [
    '$state',
    '$stateParams',
    '$ionicSlideBoxDelegate',
    'playlistsServiceSlideBox',
    'gaddumContextMenuItem',
    'importPlaylistWizard',
    'gaddumShortcutBarService'
  ];

  function playlistsListController(
    $state,
    $stateParams,
    $ionicSlideBoxDelegate,
    playlistsServiceSlideBox,
    gaddumContextMenuItem,
    importPlaylistWizard,
    gaddumShortcutBarService
  ) {
    var vm = angular.extend(this, {

    });

    // attaching these methods to ng-mousedown/up on ion-items
    // makes swiping the item not cause the slidebox to move
    vm.preventSlideBox = function preventSlideBox() {
      $ionicSlideBoxDelegate.enableSlide(false);
    };
    vm.allowSlideBox = function allowSlideBox(e) {
      $ionicSlideBoxDelegate.enableSlide(true);
    };

    vm.groupsList = playlistsServiceSlideBox.playlistsList;

    function init() {


          /* setInterval(function() {
              vm.genreScrollChecker();
          }, 100); */
      };
      init();
      

  }
})();
