(function() {
	'use strict';

	angular
		.module('gaddum.selector', [
		])

})();