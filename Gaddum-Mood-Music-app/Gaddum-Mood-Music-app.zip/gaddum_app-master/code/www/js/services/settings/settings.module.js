(function() {
	'use strict';

	angular
		.module('gaddum.settings', [
		])

})();