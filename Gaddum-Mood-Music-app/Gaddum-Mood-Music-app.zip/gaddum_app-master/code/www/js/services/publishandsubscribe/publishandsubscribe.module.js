(function() {
	'use strict';

	angular
		.module('gaddum.publishandsubscribe', [
		])

})();