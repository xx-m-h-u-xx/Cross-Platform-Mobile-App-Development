(function() {
	'use strict';

	angular
		.module('gaddum.models', [
      'utilitiesjs'
		]);

})();
