(function() {
	'use strict';

	angular
		.module('gaddum.streaming', [
      'gaddum.intelligenttrackselector'
		]);

})();
