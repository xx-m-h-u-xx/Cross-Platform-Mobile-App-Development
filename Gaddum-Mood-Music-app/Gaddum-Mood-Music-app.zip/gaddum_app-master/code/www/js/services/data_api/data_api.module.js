(function() {
	'use strict';

	angular
		.module('dataapijs', []);
})();