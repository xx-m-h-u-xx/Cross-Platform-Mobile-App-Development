(function() {
	'use strict';

	angular
		.module('utilitiesjs', []);
})();