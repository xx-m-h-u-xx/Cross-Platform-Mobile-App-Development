(function() {
	'use strict';

	angular
		.module('gaddum.playlist', [
		])

})();