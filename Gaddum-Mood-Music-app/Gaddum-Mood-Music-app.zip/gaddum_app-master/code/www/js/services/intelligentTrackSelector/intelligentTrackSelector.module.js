(function() {
	'use strict';

	angular
		.module('gaddum.intelligenttrackselector', [
		]);

})();
