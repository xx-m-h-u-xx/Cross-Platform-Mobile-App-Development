(function() {
	'use strict';

	angular
		.module('gaddum.connection', []);
})();