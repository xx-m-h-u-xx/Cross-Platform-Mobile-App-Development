(function(){
  'use strict';

  angular
    .module('gaddum.playermenu')
    .controller('gaddumPlayerMenuController', gaddumPlayerMenuController);

  gaddumPlayerMenuController.$inject = [

  ];

  function gaddumPlayerMenuController(

  ) {
    var gpmc = angular.extend(this, {

    });
    return gpmc;
  }
})();
