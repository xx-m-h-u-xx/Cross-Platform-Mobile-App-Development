with id_last_row(
    SELECT LAST_INSERT_ROW_ID
)