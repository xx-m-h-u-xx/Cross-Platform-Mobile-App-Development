SELECT * FROM tracks t1 
WHERE  
t1.id = ?1 ;