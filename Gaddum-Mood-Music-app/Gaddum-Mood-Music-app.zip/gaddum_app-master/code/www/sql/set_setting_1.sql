UPDATE settings
SET 
    value=?2
WHERE
    id=?1;