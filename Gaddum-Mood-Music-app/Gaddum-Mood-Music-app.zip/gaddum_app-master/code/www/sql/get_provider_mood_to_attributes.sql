SELECT * FROM music_provider_mood_to_attributes
WHERE
[provider] = ?1
AND
[mood] = ?2