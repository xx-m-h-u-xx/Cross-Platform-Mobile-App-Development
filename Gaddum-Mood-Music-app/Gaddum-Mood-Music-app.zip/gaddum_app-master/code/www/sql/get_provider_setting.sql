SELECT * FROM music_provider_settings
WHERE
[provider] = ?1
AND
[id] = ?2