UPDATE playlists
SET 
    [name]=?1
WHERE
    id=?2;

