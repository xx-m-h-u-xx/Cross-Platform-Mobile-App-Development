SELECT *
FROM base64_resources 
WHERE id = ?1;