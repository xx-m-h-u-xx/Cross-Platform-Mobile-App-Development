SELECT *
FROM supported_timeslots; 