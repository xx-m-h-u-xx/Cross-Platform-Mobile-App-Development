# Thanks to...

This project was funded via the [Gaddum]() and [MMU](https://www2.mmu.ac.uk/) and mentored by [DigitalLabs@MMU](https://digitallabs.mmu.ac.uk/) as a [DigitalLabs Summer Project](https://digitallabs.mmu.ac.uk/what-we-do/teaching/). It is the work of DigitalLabs and students [Kei Gibbings](https://github.com/KeiPG) and [Jothan Taylor](https://github.com/CerealSuperhero).

The application makes use of the [Jeeliz](https://jeeliz.com/) Facial Recognition and Tracking libraries. You can find out more about them [here](https://github.com/jeeliz/jeelizWeboji), and their licensing terms [here](https://github.com/jeeliz/jeelizWeboji#license). Jeeliz were fantastic in the support of our project. Thanks Jeeliz; without your help, we wouldn't have been able to release on iOS.



![](./DigitalLabsLogo_512x512.png)

![](./logo_mmu.png)

![](https://jeeliz.com/wp-content/uploads/2018/09/logojeeliz200.png)